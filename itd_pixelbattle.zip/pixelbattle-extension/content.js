(function(){
'use strict';
const P=[[255,255,255],[228,228,228],[136,136,136],[34,34,34],[0,0,0],[90,48,29],[160,106,66],[255,196,140],[109,0,26],[190,0,57],[229,0,0],[255,56,129],[255,167,209],[222,16,127],[229,149,0],[255,168,0],[229,217,0],[255,248,184],[0,95,57],[2,190,1],[148,224,68],[0,117,111],[0,0,234],[0,131,199],[54,144,234],[0,211,221],[81,233,244],[73,58,193],[106,92,255],[180,74,192],[129,30,159],[43,45,66],[26,26,26],[255,56,56],[2,190,1],[5,0,255]];
const CW=2512,CH=1296;

let stencils=[],hovId=null,dragId=null,dsx=0,dsy=0,dpx=0,dpy=0;
let oc=null,octx=null,ctrlEl=null,ctrlLock=null,ctrlEye=null,overCtrl=false;
let rafId=null,dirty=true,lastMK='';
let bitmapCache={};
let doneCache={},doneCacheKey='',doneTs=0;
const DONE_TTL=5000;

const gc=()=>document.querySelector('canvas._6v8P-A3V')||document.querySelector('canvas');

function mat(){
  const c=gc();if(!c)return null;
  const sc=parseFloat(c.dataset.pbScale),tx=parseFloat(c.dataset.pbTx),ty=parseFloat(c.dataset.pbTy);
  return isNaN(sc)?null:{sc,tx,ty};
}

function hitBox(ex,ey,s,m){
  if(!s.stencil)return false;
  const rx=innerWidth/CW,ry=innerHeight/CH;
  const gx=(ex/rx-m.tx)/m.sc,gy=(ey/ry-m.ty)/m.sc;
  return gx>=s.posX&&gx<s.posX+s.stencil.width&&gy>=s.posY&&gy<s.posY+s.stencil.height;
}

// Build offscreen canvas for a stencil, excluding done pixels
function getBitmap(s,done){
  const doneKey=done&&done.size?[...done].sort().join(';'):'';
  const k=s.id+'_'+s.stencil.width+'_'+s.stencil.height+'_'+doneKey.length;
  if(bitmapCache[k])return bitmapCache[k];

  const sw=s.stencil.width,sh=s.stencil.height;
  const c=new OffscreenCanvas(sw,sh);
  const ctx=c.getContext('2d');
  const id=ctx.createImageData(sw,sh);
  const d=id.data;
  for(let y=0;y<sh;y++){
    for(let x=0;x<sw;x++){
      const idx=s.stencil.pixels[y][x];
      if(idx===null)continue;
      if(done&&done.has(x+','+y))continue;
      const i=(y*sw+x)*4,[r,g,b]=P[idx];
      d[i]=r;d[i+1]=g;d[i+2]=b;d[i+3]=255;
    }
  }
  ctx.putImageData(id,0,0);
  bitmapCache[k]=c;
  return c;
}

function buildDoneCache(m){
  const now=Date.now();
  const posKey=stencils.filter(s=>s.visible&&s.stencil).map(s=>s.id+s.posX+s.posY).join('|');
  if(posKey===doneCacheKey&&now-doneTs<DONE_TTL)return;
  doneCacheKey=posKey;doneTs=now;
  const gameCanvas=gc();if(!gameCanvas)return;

  for(const s of stencils){
    if(!s.stencil||!s.visible){doneCache[s.id]=new Set();continue;}
    const x0=Math.floor(m.tx+s.posX*m.sc),y0=Math.floor(m.ty+s.posY*m.sc);
    const x1=Math.ceil(m.tx+(s.posX+s.stencil.width)*m.sc);
    const y1=Math.ceil(m.ty+(s.posY+s.stencil.height)*m.sc);
    const cx0=Math.max(0,x0),cy0=Math.max(0,y0);
    const cx1=Math.min(gameCanvas.width,x1),cy1=Math.min(gameCanvas.height,y1);
    const done=new Set();
    if(cx1>cx0&&cy1>cy0){
      let px=null;
      try{px=gameCanvas.getContext('2d').getImageData(cx0,cy0,cx1-cx0,cy1-cy0).data;}catch(e){}
      if(px){
        const W=cx1-cx0;
        for(let py=0;py<s.stencil.height;py++){
          for(let pxx=0;pxx<s.stencil.width;pxx++){
            const idx=s.stencil.pixels[py][pxx];if(idx===null)continue;
            const cx=Math.floor(m.tx+(s.posX+pxx+0.5)*m.sc)-cx0;
            const cy=Math.floor(m.ty+(s.posY+py+0.5)*m.sc)-cy0;
            if(cx<0||cy<0||cx>=W||cy>=cy1-cy0)continue;
            const i=(cy*W+cx)*4,[er,eg,eb]=P[idx];
            if(Math.abs(px[i]-er)<=10&&Math.abs(px[i+1]-eg)<=10&&Math.abs(px[i+2]-eb)<=10)done.add(pxx+','+py);
          }
        }
      }
    }
    doneCache[s.id]=done;
  }
}

function ensureOC(){
  if(oc&&oc.isConnected)return;
  oc=document.createElement('canvas');
  oc.style.cssText='position:fixed;top:0;left:0;pointer-events:none;image-rendering:pixelated;image-rendering:crisp-edges;z-index:9998;';
  document.documentElement.appendChild(oc);
  octx=oc.getContext('2d');
  octx.imageSmoothingEnabled=false; // ← фикс размытых пикселей
  sizeOC();
}
function sizeOC(){
  if(!oc)return;
  const dpr=devicePixelRatio||1;
  oc.width=Math.round(innerWidth*dpr);oc.height=Math.round(innerHeight*dpr);
  oc.style.width=innerWidth+'px';oc.style.height=innerHeight+'px';
  // Восстанавливаем после resize (resize сбрасывает context state)
  if(octx)octx.imageSmoothingEnabled=false;
  dirty=true;
}

function mkBtn(icon){
  const b=document.createElement('button');b.textContent=icon;
  b.style.cssText='width:24px;height:24px;border-radius:4px;border:1.5px solid rgba(255,255,255,0.3);background:rgba(0,0,0,0.72);color:#fff;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;line-height:1;padding:0;pointer-events:auto;';
  return b;
}
function ensureCtrl(){
  if(ctrlEl&&ctrlEl.isConnected)return;
  ctrlEl=document.createElement('div');
  ctrlEl.style.cssText='position:fixed;z-index:10000;display:none;gap:3px;pointer-events:auto;';
  ctrlLock=mkBtn('🔓');ctrlEye=mkBtn('👁');
  ctrlEl.addEventListener('mouseenter',()=>{overCtrl=true;});
  ctrlEl.addEventListener('mouseleave',()=>{overCtrl=false;if(!hovId)ctrlEl.style.display='none';});
  ctrlLock.addEventListener('click',e=>{
    e.stopPropagation();const s=stencils.find(s=>s.id===hovId);if(!s)return;
    s.locked=!s.locked;syncCtrl(s);chrome.storage.local.set({pixelStencils:stencils});
  });
  ctrlEye.addEventListener('click',e=>{
    e.stopPropagation();const s=stencils.find(s=>s.id===hovId);if(!s)return;
    s.visible=!s.visible;syncCtrl(s);dirty=true;doneCacheKey='';
    chrome.storage.local.set({pixelStencils:stencils});
  });
  ctrlEl.append(ctrlLock,ctrlEye);
  document.documentElement.appendChild(ctrlEl);
}
function syncCtrl(s){
  if(!ctrlLock||!ctrlEye||!s)return;
  ctrlLock.textContent=s.locked?'🔒':'🔓';
  ctrlLock.style.borderColor=s.locked?'rgba(255,80,80,.8)':'rgba(255,255,255,.3)';
  ctrlEye.textContent=s.visible?'👁':'🙈';
  ctrlEye.style.borderColor=s.visible?'rgba(255,255,255,.3)':'rgba(255,200,80,.8)';
}
function posCtrl(s,m){
  if(!ctrlEl||!s?.stencil)return;
  const rx=innerWidth/CW,ry=innerHeight/CH;
  const x1=(m.tx+s.posX*m.sc)*rx,y1=(m.ty+s.posY*m.sc)*ry;
  const x2=(m.tx+(s.posX+s.stencil.width)*m.sc)*rx,sw=x2-x1;
  ctrlEl.style.flexDirection='row';
  ctrlEl.style.left=(sw<58?Math.max(4,x1):Math.min(innerWidth-56,Math.max(4,x2-54)))+'px';
  ctrlEl.style.top=Math.max(4,y1+4)+'px';
  ctrlEl.style.display='flex';syncCtrl(s);
}

function render(){
  if(!dirty)return;dirty=false;
  if(!octx)return;
  const m=mat();
  octx.clearRect(0,0,oc.width,oc.height);
  if(!m)return;

  buildDoneCache(m);

  // imageSmoothingEnabled сбрасывается при clearRect в некоторых браузерах — ставим каждый кадр
  octx.imageSmoothingEnabled=false;

  const dpr=devicePixelRatio||1;
  const rx=(innerWidth/CW)*dpr,ry=(innerHeight/CH)*dpr;

  for(const s of stencils){
    if(!s.stencil)continue;
    if(s.visible){
      const done=doneCache[s.id]||new Set();
      const bmp=getBitmap(s,done);
      octx.save();
      octx.setTransform(m.sc*rx,0,0,m.sc*ry,m.tx*rx,m.ty*ry);
      octx.globalAlpha=s.opacity;
      octx.imageSmoothingEnabled=false;
      octx.drawImage(bmp,s.posX,s.posY,s.stencil.width,s.stencil.height);
      if(dragId===s.id){
        octx.globalAlpha=0.9;octx.strokeStyle='#fff';
        octx.lineWidth=1.5/(m.sc*rx);
        octx.strokeRect(s.posX-.5,s.posY-.5,s.stencil.width+1,s.stencil.height+1);
      }
      if(s.displayMode==='grid'){
        octx.globalAlpha=s.opacity*.35;octx.strokeStyle='rgba(0,0,0,.5)';octx.lineWidth=0.08;
        for(let x=s.posX;x<=s.posX+s.stencil.width;x++){octx.beginPath();octx.moveTo(x,s.posY);octx.lineTo(x,s.posY+s.stencil.height);octx.stroke();}
        for(let y=s.posY;y<=s.posY+s.stencil.height;y++){octx.beginPath();octx.moveTo(s.posX,y);octx.lineTo(s.posX+s.stencil.width,y);octx.stroke();}
      }
      octx.restore();
    }
    if(!s.visible&&hovId===s.id){
      octx.save();
      octx.setTransform(m.sc*rx,0,0,m.sc*ry,m.tx*rx,m.ty*ry);
      octx.globalAlpha=0.3;octx.strokeStyle='#fff';
      octx.lineWidth=1/(m.sc*rx);octx.setLineDash([3/(m.sc*rx),3/(m.sc*rx)]);
      octx.strokeRect(s.posX,s.posY,s.stencil.width,s.stencil.height);
      octx.restore();
    }
  }
}

function startLoop(){
  if(rafId)return;
  (function tick(){
    const m=mat();
    if(m){
      const k=`${m.sc.toFixed(4)},${m.tx.toFixed(1)},${m.ty.toFixed(1)}`;
      if(k!==lastMK){lastMK=k;dirty=true;}
      if((hovId||overCtrl)&&ctrlEl){const s=stencils.find(s=>s.id===hovId);if(s)posCtrl(s,m);}
    }
    render();
    rafId=requestAnimationFrame(tick);
  })();
}

document.addEventListener('mousedown',e=>{
  if(ctrlEl?.contains(e.target))return;
  const m=mat();if(!m)return;
  for(let i=stencils.length-1;i>=0;i--){
    const s=stencils[i];
    if(s.visible&&!s.locked&&hitBox(e.clientX,e.clientY,s,m)){
      dragId=s.id;dsx=e.clientX;dsy=e.clientY;dpx=s.posX;dpy=s.posY;
      document.body.style.cursor='grabbing';e.preventDefault();e.stopPropagation();return;
    }
  }
},true);
document.addEventListener('mousemove',e=>{
  const m=mat();if(!m)return;
  if(!dragId){
    let nh=null;
    for(let i=stencils.length-1;i>=0;i--){if(hitBox(e.clientX,e.clientY,stencils[i],m)){nh=stencils[i].id;break;}}
    if(nh!==hovId){
      hovId=nh;ensureCtrl();
      if(hovId){const s=stencils.find(s=>s.id===hovId);posCtrl(s,m);document.body.style.cursor=(s&&s.visible&&!s.locked)?'grab':'default';dirty=true;}
      else{if(!overCtrl)ctrlEl.style.display='none';document.body.style.cursor='';dirty=true;}
    }else if(hovId){const s=stencils.find(s=>s.id===hovId);if(s)posCtrl(s,m);}
    return;
  }
  const s=stencils.find(s=>s.id===dragId);if(!s)return;
  const rx=innerWidth/CW,ry=innerHeight/CH;
  const nx=Math.max(0,Math.min(1023,dpx+Math.round((e.clientX-dsx)/(m.sc*rx))));
  const ny=Math.max(0,Math.min(1023,dpy+Math.round((e.clientY-dsy)/(m.sc*ry))));
  if(nx!==s.posX||ny!==s.posY){s.posX=nx;s.posY=ny;dirty=true;doneCacheKey='';}
},true);
document.addEventListener('mouseup',()=>{
  if(!dragId)return;dragId=null;document.body.style.cursor='';dirty=true;
  chrome.storage.local.set({pixelStencils:stencils});
},true);

window.addEventListener('resize',sizeOC);

chrome.runtime.onMessage.addListener((msg,_,res)=>{
  if(msg.action==='setAll'){
    stencils=msg.stencils;dirty=true;doneCacheKey='';bitmapCache={};
    ensureOC();ensureCtrl();startLoop();res({ok:true});
  }
  if(msg.action==='updateStencil'){
    const s=stencils.find(s=>s.id===msg.id);
    if(s){s[msg.field]=msg.value;dirty=true;doneCacheKey='';bitmapCache={};}
    res({ok:true});
  }
  if(msg.action==='getPositions'){
    res({positions:stencils.map(s=>({id:s.id,posX:s.posX,posY:s.posY,visible:s.visible,locked:s.locked}))});
  }
  return true;
});

function init(){
  chrome.storage.local.get(['pixelStencils','pixelStencil'],data=>{
    if(data.pixelStencils)stencils=data.pixelStencils;
    else if(data.pixelStencil?.stencil){
      const o=data.pixelStencil;
      stencils=[{id:'st_1',name:'Арт 1',stencil:o.stencil,posX:o.posX||0,posY:o.posY||0,opacity:o.opacity||0.6,visible:o.visible!==false,locked:!!o.locked,displayMode:o.displayMode||'normal',imageDataURL:null}];
      chrome.storage.local.set({pixelStencils:stencils});
    }
    if(stencils.length){const t=()=>gc()?(ensureOC(),ensureCtrl(),startLoop()):setTimeout(t,300);t();}
  });
}

if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);
else init();
})();
