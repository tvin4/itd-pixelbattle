const P=[[255,255,255],[228,228,228],[136,136,136],[34,34,34],[0,0,0],[90,48,29],[160,106,66],[255,196,140],[109,0,26],[190,0,57],[229,0,0],[255,56,129],[255,167,209],[222,16,127],[229,149,0],[255,168,0],[229,217,0],[255,248,184],[0,95,57],[2,190,1],[148,224,68],[0,117,111],[0,0,234],[0,131,199],[54,144,234],[0,211,221],[81,233,244],[73,58,193],[106,92,255],[180,74,192],[129,30,159],[43,45,66],[26,26,26],[255,56,56],[2,190,1],[5,0,255]];

document.getElementById('colorStrip').innerHTML=P.map(([r,g,b])=>{const h='#'+[r,g,b].map(v=>v.toString(16).padStart(2,'0')).join('');return`<div class="cdot" style="background:${h}" title="${h}"></div>`;}).join('');

function nearest(r,g,b){let b0=0,d=Infinity;P.forEach(([pr,pg,pb],i)=>{const dd=2*(r-pr)**2+4*(g-pg)**2+3*(b-pb)**2;if(dd<d){d=dd;b0=i;}});return b0;}

function processImg(img,w){
  const h=Math.round(img.naturalHeight/img.naturalWidth*w);
  const c=document.createElement('canvas');c.width=w;c.height=h;
  c.getContext('2d').drawImage(img,0,0,w,h);
  const{data}=c.getContext('2d').getImageData(0,0,w,h);
  const px=[];
  for(let y=0;y<h;y++){const row=[];for(let x=0;x<w;x++){const i=(y*w+x)*4;row.push(data[i+3]<128?null:nearest(data[i],data[i+1],data[i+2]));}px.push(row);}
  return{pixels:px,width:w,height:h};
}

function drawPreview(s){
  const c=document.getElementById('previewCanvas');c.width=s.width;c.height=s.height;
  const ctx=c.getContext('2d'),id=ctx.createImageData(s.width,s.height);
  s.pixels.forEach((row,y)=>row.forEach((idx,x)=>{const i=(y*s.width+x)*4;if(idx===null){id.data[i+3]=0;return;}const[r,g,b]=P[idx];id.data[i]=r;id.data[i+1]=g;id.data[i+2]=b;id.data[i+3]=255;}));
  ctx.putImageData(id,0,0);
}

function loadImg(url){return new Promise(r=>{const i=new Image();i.onload=()=>r(i);i.src=url;});}

const $=id=>document.getElementById(id);
function st(msg,t='info'){$('status').textContent=msg;$('status').className='status '+t;}
function uid(){return'st_'+Date.now()+'_'+Math.random().toString(36).slice(2,6);}

let stencils=[],activeId=null,activeImg=null;
const ga=()=>stencils.find(s=>s.id===activeId)||null;

async function getTab(){const[t]=await chrome.tabs.query({active:true,currentWindow:true});return t||null;}
async function send(action,extra){
  const t=await getTab();if(!t)return null;
  return new Promise(r=>chrome.tabs.sendMessage(t.id,{action,...extra},res=>r(chrome.runtime.lastError?null:res)));
}
function live(id,field,value){
  send('updateStencil',{id,field,value});
  chrome.storage.local.get('pixelStencils',d=>{const a=d.pixelStencils||[];const s=a.find(s=>s.id===id);if(s){s[field]=value;chrome.storage.local.set({pixelStencils:a});}});
}
function saveAll(){chrome.storage.local.set({pixelStencils:stencils});}

let dark=false;
$('darkBtn').addEventListener('click',()=>{dark=!dark;document.body.classList.toggle('dark',dark);$('darkBtn').textContent=dark?'☀':'🌙';chrome.storage.local.set({darkMode:dark});});

function renderList(){
  const list=$('stencilList');list.innerHTML='';
  stencils.forEach(s=>{
    const row=document.createElement('div');row.className='srow'+(s.id===activeId?' active':'');
    const nw=document.createElement('div');nw.className='sname';
    const ni=document.createElement('input');ni.value=s.name;ni.spellcheck=false;
    ni.addEventListener('click',e=>e.stopPropagation());
    ni.addEventListener('change',()=>{s.name=ni.value;saveAll();});
    nw.appendChild(ni);
    const eye=document.createElement('button');eye.className='rbtn'+(s.visible?'':' muted');eye.textContent=s.visible?'👁':'🙈';
    eye.addEventListener('click',e=>{e.stopPropagation();s.visible=!s.visible;eye.textContent=s.visible?'👁':'🙈';eye.className='rbtn'+(s.visible?'':' muted');live(s.id,'visible',s.visible);});
    const del=document.createElement('button');del.className='rbtn';del.textContent='×';del.style.color='#999';
    del.addEventListener('click',e=>{e.stopPropagation();stencils=stencils.filter(x=>x.id!==s.id);if(activeId===s.id)activeId=stencils[0]?.id||null;saveAll();send('setAll',{stencils});renderList();loadEditor();});
    row.append(nw,eye,del);
    row.addEventListener('click',()=>{activeId=s.id;renderList();loadEditor();});
    list.appendChild(row);
  });
}

async function loadEditor(){
  const s=ga();
  if(!s){$('editor').classList.add('hidden');return;}
  $('editor').classList.remove('hidden');
  $('editorTitle').textContent='Редактирование: '+s.name;
  $('opacitySlider').value=Math.round((s.opacity||0.6)*100);$('opacityVal').textContent=$('opacitySlider').value;
  $('posX').value=s.posX||0;$('posY').value=s.posY||0;
  $('displayMode').value=s.displayMode||'normal';$('applyBtn').disabled=!s.stencil;
  if(s.imageDataURL&&!activeImg)activeImg=await loadImg(s.imageDataURL);
  if(s.stencil){$('preview-wrap').style.display='block';$('widthSlider').value=s.stencil.width;$('wVal').textContent=s.stencil.width;$('hVal').textContent=s.stencil.height;drawPreview(s.stencil);}
  else{$('preview-wrap').style.display='none';$('widthSlider').value=50;$('wVal').textContent=50;$('hVal').textContent='—';}
}

$('addBtn').addEventListener('click',()=>{
  const s={id:uid(),name:`Арт ${stencils.length+1}`,stencil:null,posX:0,posY:0,opacity:0.6,visible:true,locked:false,displayMode:'normal',imageDataURL:null};
  stencils.push(s);activeId=s.id;activeImg=null;renderList();loadEditor();$('fileInput').value='';st('Загрузи изображение','info');
});

$('fileInput').addEventListener('change',e=>{
  const f=e.target.files[0];if(!f)return;
  const r=new FileReader();
  r.onload=ev=>{const i=new Image();i.onload=()=>{activeImg=i;const s=ga();if(!s)return;s.imageDataURL=ev.target.result;rebuildStencil();if(!s.posX&&!s.posY&&s.stencil){const cx=Math.max(0,Math.round((1024-s.stencil.width)/2));const cy=Math.max(0,Math.round((1024-s.stencil.height)/2));s.posX=cx;s.posY=cy;$('posX').value=cx;$('posY').value=cy;}$('applyBtn').disabled=false;$('preview-wrap').style.display='block';st(`${i.naturalWidth}×${i.naturalHeight} → ${s.stencil?.width}×${s.stencil?.height}px`,'ok');};i.src=ev.target.result;};
  r.readAsDataURL(f);
});

$('widthSlider').addEventListener('input',()=>{
  if(!activeImg){st('Сначала загрузи изображение','err');return;}
  rebuildStencil();const s=ga();
  if(s?.stencil)send('updateStencil',{id:s.id,field:'stencil',value:s.stencil});
});

function rebuildStencil(){
  const s=ga();if(!s||!activeImg)return;
  const w=+$('widthSlider').value,h=Math.round(activeImg.naturalHeight/activeImg.naturalWidth*w);
  $('wVal').textContent=w;$('hVal').textContent=h;s.stencil=processImg(activeImg,w);drawPreview(s.stencil);
}

$('opacitySlider').addEventListener('input',()=>{const v=+$('opacitySlider').value;$('opacityVal').textContent=v;const s=ga();if(s){s.opacity=v/100;live(s.id,'opacity',v/100);}});

function clamp(id){const el=$(id);el.value=Math.max(0,Math.min(1023,+el.value||0));}
$('posX').addEventListener('change',()=>{clamp('posX');const s=ga();if(s){s.posX=+$('posX').value;live(s.id,'posX',s.posX);}});
$('posY').addEventListener('change',()=>{clamp('posY');const s=ga();if(s){s.posY=+$('posY').value;live(s.id,'posY',s.posY);}});

$('centerBtn').addEventListener('click',()=>{
  const s=ga();if(!s?.stencil)return;
  const cx=Math.max(0,Math.round((1024-s.stencil.width)/2));
  const cy=Math.max(0,Math.round((1024-s.stencil.height)/2));
  $('posX').value=cx;$('posY').value=cy;s.posX=cx;s.posY=cy;
  live(s.id,'posX',cx);live(s.id,'posY',cy);st(`Центр: (${cx}, ${cy})`,'ok');
});

$('displayMode').addEventListener('change',()=>{const s=ga();if(s){s.displayMode=$('displayMode').value;live(s.id,'displayMode',s.displayMode);}});

$('applyBtn').addEventListener('click',async()=>{
  const s=ga();if(!s?.stencil)return;
  s.posX=+$('posX').value||0;s.posY=+$('posY').value||0;
  s.opacity=+$('opacitySlider').value/100;s.displayMode=$('displayMode').value;s.visible=true;
  saveAll();renderList();
  const res=await send('setAll',{stencils});
  st(res?'✓ Применено':'Перезагрузи страницу',res?'ok':'err');
});

setInterval(async()=>{
  const res=await send('getPositions',{});if(!res)return;
  let ch=false;
  res.positions.forEach(p=>{const s=stencils.find(s=>s.id===p.id);if(s&&(s.posX!==p.posX||s.posY!==p.posY)){s.posX=p.posX;s.posY=p.posY;ch=true;}});
  if(ch&&activeId){$('posX').value=ga()?.posX||0;$('posY').value=ga()?.posY||0;}
},400);

(async()=>{
  const d=await chrome.storage.local.get(['pixelStencils','pixelStencil','darkMode']);
  if(d.darkMode){dark=true;document.body.classList.add('dark');$('darkBtn').textContent='☀';}
  if(d.pixelStencils?.length){stencils=d.pixelStencils;activeId=stencils[0].id;}
  else if(d.pixelStencil?.stencil){
    const o=d.pixelStencil;
    stencils=[{id:'st_1',name:'Арт 1',stencil:o.stencil,posX:o.posX||0,posY:o.posY||0,opacity:o.opacity||0.6,visible:o.visible!==false,locked:!!o.locked,displayMode:o.displayMode||'normal',imageDataURL:null}];
    activeId='st_1';saveAll();
  }
  renderList();await loadEditor();
  if(stencils.length)st(`Загружено: ${stencils.length} трафарет(ов)`,'ok');
})();
