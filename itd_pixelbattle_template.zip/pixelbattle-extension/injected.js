(function(){
const o=CanvasRenderingContext2D.prototype,os=o.scale,ot=o.translate;
let _s=null,_t=null;
function ig(c){return c.canvas&&c.canvas.classList.contains('_6v8P-A3V');}
o.scale=function(sx,sy){os.call(this,sx,sy);if(!ig(this))return;if(_s===null){_s=sx;}else if(_t!==null){this.canvas.dataset.pbScale=_s*sx;this.canvas.dataset.pbTx=_s*_t[0];this.canvas.dataset.pbTy=_s*_t[1];_s=null;_t=null;}};
o.translate=function(x,y){ot.call(this,x,y);if(!ig(this))return;if(_s!==null)_t=[x,y];};
})();
